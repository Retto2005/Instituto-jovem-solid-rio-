
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.11.0/firebase-app.js";
import {
  getAuth, signInWithEmailAndPassword, signOut, onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/10.11.0/firebase-auth.js";
import {
  getFirestore, collection, addDoc, getDocs, deleteDoc, doc, updateDoc
} from "https://www.gstatic.com/firebasejs/10.11.0/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyBw5pez67jw7Wc-oqptF_cknG8ipiVyDD0",
  authDomain: "instituto-jovem-solidari-5a4df.firebaseapp.com",
  projectId: "instituto-jovem-solidari-5a4df",
  storageBucket: "instituto-jovem-solidari-5a4df.appspot.com",
  messagingSenderId: "721865340408",
  appId: "1:721865340408:web:4e862559cd03aad6f4120d"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

const loginForm = document.getElementById("loginForm");
const loginContainer = document.getElementById("loginContainer");
const appContainer = document.getElementById("appContainer");
const logoutBtn = document.getElementById("logoutBtn");
const abaCadastro = document.getElementById("abaCadastro");
const abaDashboard = document.getElementById("abaDashboard");
const userForm = document.getElementById("userForm");
const userTable = document.getElementById("userTable");
const filtroInput = document.getElementById("filtro");

let usuarios = [];
let usuariosFiltrados = [];

loginForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  const email = loginForm.loginEmail.value;
  const password = loginForm.loginPassword.value;
  try {
    await signInWithEmailAndPassword(auth, email, password);
  } catch (error) {
    alert("Erro no login: " + error.message);
  }
});

logoutBtn.addEventListener("click", () => {
  signOut(auth);
});

onAuthStateChanged(auth, (user) => {
  if (user) {
    loginContainer.classList.add("hidden");
    appContainer.classList.remove("hidden");
    carregarUsuarios();
  } else {
    loginContainer.classList.remove("hidden");
    appContainer.classList.add("hidden");
  }
});

userForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  const data = Object.fromEntries(new FormData(userForm).entries());
  try {
    await addDoc(collection(db, "usuarios"), data);
    userForm.reset();
    carregarUsuarios();
  } catch (err) {
    alert("Erro ao salvar: " + err.message);
  }
});

async function carregarUsuarios() {
  const snap = await getDocs(collection(db, "usuarios"));
  usuarios = snap.docs.map(d => ({ id: d.id, ...d.data() }));
  aplicarFiltroTabela();
  aplicarDashboard();
}

filtroInput.addEventListener("input", aplicarFiltroTabela);

function aplicarFiltroTabela() {
  const termo = filtroInput.value.toLowerCase();
  usuariosFiltrados = usuarios.filter(u =>
    u.nome?.toLowerCase().includes(termo) ||
    u.cpf?.includes(termo) ||
    u.categoria?.toLowerCase().includes(termo)
  );
  atualizarTabela();
}

function atualizarTabela() {
  userTable.innerHTML = "";
  usuariosFiltrados.forEach(u => {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td class="border p-2">${u.nome}</td>
      <td class="border p-2">${u.cpf}</td>
      <td class="border p-2">${u.categoria}</td>
      <td class="border p-2">
        <button onclick="editarUsuario('${u.id}')" class="text-blue-600">Editar</button>
        <button onclick="removerUsuario('${u.id}')" class="text-red-600 ml-2">Excluir</button>
      </td>`;
    userTable.appendChild(tr);
  });
}

window.removerUsuario = async function(id) {
  if (confirm("Deseja excluir?")) {
    await deleteDoc(doc(db, "usuarios", id));
    carregarUsuarios();
  }
};

window.editarUsuario = async function(id) {
  const user = usuarios.find(u => u.id === id);
  if (!user) return;
  for (let [key, value] of Object.entries(user)) {
    if (userForm[key]) userForm[key].value = value;
  }
  await deleteDoc(doc(db, "usuarios", id));
};

function mostrarAba(nome) {
  abaCadastro.classList.add("hidden");
  abaDashboard.classList.add("hidden");
  if (nome === "cadastro") abaCadastro.classList.remove("hidden");
  if (nome === "dashboard") {
    abaDashboard.classList.remove("hidden");
    aplicarDashboard();
  }
}

// Dashboard
const btnFiltrar = document.getElementById("btnFiltrar");
const btnExcel = document.getElementById("btnExcel");
const btnPDF = document.getElementById("btnPDF");
const filtroInicio = document.getElementById("filtroInicio");
const filtroFim = document.getElementById("filtroFim");

btnFiltrar?.addEventListener("click", aplicarDashboard);

function calcularIdade(dataNascimento) {
  const hoje = new Date();
  const nasc = new Date(dataNascimento);
  let idade = hoje.getFullYear() - nasc.getFullYear();
  const m = hoje.getMonth() - nasc.getMonth();
  if (m < 0 || (m === 0 && hoje.getDate() < nasc.getDate())) idade--;
  return idade;
}

function faixaEtaria(idade) {
  if (idade < 18) return "0-17";
  if (idade < 30) return "18-29";
  if (idade < 45) return "30-44";
  if (idade < 60) return "45-59";
  return "60+";
}

function aplicarDashboard() {
  const inicio = new Date(filtroInicio?.value || "1900-01-01");
  const fim = new Date(filtroFim?.value || "2100-01-01");

  const filtrados = usuarios.filter(u => {
    if (!u.dataNascimento) return false;
    const nasc = new Date(u.dataNascimento);
    return nasc >= inicio && nasc <= fim;
  });

  document.getElementById("totalUsuarios").textContent = filtrados.length;
  document.getElementById("ultimaAtualizacao").textContent = new Date().toLocaleString();

  const categorias = {}, bairros = {}, idades = {};
  filtrados.forEach(u => {
    const cat = u.categoria || "Não informado";
    categorias[cat] = (categorias[cat] || 0) + 1;
    const bairro = u.endereco?.split(',')[1]?.trim() || "Desconhecido";
    bairros[bairro] = (bairros[bairro] || 0) + 1;
    const idade = calcularIdade(u.dataNascimento);
    const faixa = faixaEtaria(idade);
    idades[faixa] = (idades[faixa] || 0) + 1;
  });

  document.getElementById("totalCategorias").textContent = Object.keys(categorias).length;

  new Chart(document.getElementById("categoriaChart"), {
    type: "bar",
    data: {
      labels: Object.keys(categorias),
      datasets: [{ label: "Usuários", data: Object.values(categorias) }]
    }
  });

  new Chart(document.getElementById("bairroChart"), {
    type: "doughnut",
    data: {
      labels: Object.keys(bairros),
      datasets: [{ label: "Usuários", data: Object.values(bairros) }]
    }
  });

  new Chart(document.getElementById("idadeChart"), {
    type: "pie",
    data: {
      labels: Object.keys(idades),
      datasets: [{ label: "Faixa Etária", data: Object.values(idades) }]
    }
  });
}

btnExcel?.addEventListener("click", () => {
  const ws = XLSX.utils.json_to_sheet(usuarios);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Usuários");
  XLSX.writeFile(wb, "usuarios_jovem_solidario.xlsx");
});

btnPDF?.addEventListener("click", () => {
  const { jsPDF } = window.jspdf;
  const pdf = new jsPDF();
  pdf.text("Relatório de Usuários - Instituto Jovem Solidário", 10, 10);
  usuarios.slice(0, 50).forEach((u, i) => {
    pdf.text(`${i + 1}. ${u.nome || 'Sem nome'} - ${u.categoria || 'Sem categoria'}`, 10, 20 + i * 6);
  });
  pdf.save("usuarios_jovem_solidario.pdf");
});
